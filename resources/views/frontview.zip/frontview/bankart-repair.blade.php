@extends('layouts.front')
@section('opTag')


@section('title', 'Bankart-repair')

@endsection
@section('content')

<div class="page-content bg-white">

                <!-- Inner Banner -->
                <div class="banner-wraper">
                    <div class="page-banner"
                        style="background-image:url(/Front/assets/images/banner/img1.jpg);">
                        <div class="container">
                            <div class="page-banner-entry text-center">
                                <h1>Bankart Repair</h1>
                                <!-- Breadcrumb row -->
                                <nav aria-label="breadcrumb"
                                    class="breadcrumb-row">
                                    <ul class="breadcrumb">
                                        <li class="breadcrumb-item"><a
                                                href="index-2.html"><svg
                                                    xmlns="http://www.w3.org/2000/svg"
                                                    width="22" height="22"
                                                    viewBox="0 0 24 24"
                                                    fill="none"
                                                    stroke="currentColor"
                                                    stroke-width="2"
                                                    stroke-linecap="round"
                                                    stroke-linejoin="round"
                                                    class="feather feather-home"><path
                                                        d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline
                                                        points="9 22 9 12 15 12 15 22"></polyline></svg>
                                                Home</a></li>
                                        <li class="breadcrumb-item active"
                                            aria-current="page">Bankart
                                            Repair</li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                        <img class="pt-img1 animate-wave"
                            src="{{ asset('Front/assets/images/shap/wave-blue.png') }}" alt>
                        <img class="pt-img2 animate2"
                            src="{{ asset('Front/assets/images/shap/circle-dots.png') }}" alt>
                        <img class="pt-img3 animate-rotate"
                            src="{{ asset('Front/assets/images/shap/plus-blue.png') }}" alt>
                    </div>
                    <!-- Breadcrumb row END -->
                </div>
                <!-- Inner Banner end -->

                <!-- About us -->
                <section class="section-area section-sp1">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-8 mb-30">
                                <div class="ttr-media mb-30">
                                    <img
                                        src="{{ asset('Front/assets/images/service/acl_1280.jpg') }}"
                                        class="rounded" alt>
                                </div>
                                <div class="clearfix">
                                    <div class="head-text mb-30">
                                        <h2 class="title mb-15">Bankart
                                            Repair</h2>
                                        <p class="mb-0">Bankart repair is a
                                            surgical procedure performed to
                                            address recurrent shoulder
                                            dislocations. The shoulder is a
                                            ball-and-socket joint, where the
                                            humeral head (ball) fits into the
                                            glenoid cavity (socket). Recurrent
                                            dislocations often result from a
                                            Bankart lesion, where the labrum (a
                                            soft cartilage rim around the
                                            socket) tears and causes
                                            instability. This procedure is
                                            designed to reattach the labrum and
                                            tighten the shoulder ligaments,
                                            restoring stability.</p>
                                    </div>

                                </div>
                                <!-- symptoms start -->
                                <div class>
                                    <h4 class="title">Symptoms of Bankart
                                        Repair</h4>
                                    <!-- <p>Cartilage damage often presents the following symptoms:</p> -->
                                    <div class="row align-items-center">
                                        <div class="col-md-12 mb-30">
                                            <ul class="list-check-squer mb-0">
                                                <li>Frequent shoulder
                                                    dislocations: Recurrent
                                                    episodes of the shoulder
                                                    popping out of its socket,
                                                    often from minor
                                                    movements.</li>
                                                <li>Pain: Pain during or after
                                                    dislocation and in
                                                    activities that stress the
                                                    shoulder.</li>
                                                <li>Feeling of instability: The
                                                    sensation that the shoulder
                                                    is loose or might dislocate
                                                    with certain movements.</li>
                                                <li>Weakness: Difficulty in
                                                    lifting or holding objects
                                                    due to instability.</li>
                                                <li>Limited range of motion:
                                                    Difficulty raising the arm
                                                    or performing overhead
                                                    movements.
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <!-- symptoms end-->
                                <div class="clearfix">
                                    <div class="head-text mb-30">
                                        <h4 class="title mb-10">Popular
                                            Questions</h4>
                                    </div>
                                    <div class="accordion ttr-accordion1"
                                        id="accordionRow1">
                                        <div class="accordion-item">
                                            <h2 class="accordion-header"
                                                id="heading1">
                                                <button class="accordion-button"
                                                    type="button"
                                                    data-bs-toggle="collapse"
                                                    data-bs-target="#collapse1"
                                                    aria-expanded="true"
                                                    aria-controls="collapse1">What
                                                    is Bankart Repair?</button>
                                            </h2>
                                            <div id="collapse1"
                                                class="accordion-collapse collapse show"
                                                aria-labelledby="heading1"
                                                data-bs-parent="#accordionRow1">
                                                <div class="accordion-body">
                                                    <p class="mb-0">Bankart
                                                        Repair is a surgical
                                                        procedure to fix a torn
                                                        labrum in the shoulder,
                                                        usually after recurrent
                                                        dislocations.</p>

                                                </div>
                                            </div>
                                        </div>
                                        <div class="accordion-item">
                                            <h2 class="accordion-header"
                                                id="heading2">
                                                <button
                                                    class="accordion-button collapsed"
                                                    type="button"
                                                    data-bs-toggle="collapse"
                                                    data-bs-target="#collapse2"
                                                    aria-expanded="false"
                                                    aria-controls="collapse2">
                                                    When is Bankart Repair
                                                    necessary?</button>
                                            </h2>
                                            <div id="collapse2"
                                                class="accordion-collapse collapse"
                                                aria-labelledby="heading2"
                                                data-bs-parent="#accordionRow1">
                                                <div class="accordion-body">
                                                    <p class="mb-0">It’s needed
                                                        when the labrum (a rim
                                                        of cartilage) is torn
                                                        from the socket, causing
                                                        shoulder instability and
                                                        repeated dislocations.
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="accordion-item">
                                            <h2 class="accordion-header"
                                                id="heading3">
                                                <button
                                                    class="accordion-button collapsed"
                                                    type="button"
                                                    data-bs-toggle="collapse"
                                                    data-bs-target="#collapse3"
                                                    aria-expanded="false"
                                                    aria-controls="collapse3">How
                                                    is Bankart Repair
                                                    performed?</button>
                                            </h2>
                                            <div id="collapse3"
                                                class="accordion-collapse collapse"
                                                aria-labelledby="heading3"
                                                data-bs-parent="#accordionRow1">
                                                <div class="accordion-body">
                                                    <p class="mb-0">The torn
                                                        labrum is reattached to
                                                        the shoulder socket
                                                        using small anchors and
                                                        sutures, often via
                                                        arthroscopic (keyhole)
                                                        surgery.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="accordion-item">
                                            <h2 class="accordion-header"
                                                id="heading4">
                                                <button
                                                    class="accordion-button collapsed"
                                                    type="button"
                                                    data-bs-toggle="collapse"
                                                    data-bs-target="#collapse4"
                                                    aria-expanded="false"
                                                    aria-controls="collapse4">
                                                    Is Bankart Repair a major
                                                    surgery?</button>
                                            </h2>
                                            <div id="collapse4"
                                                class="accordion-collapse collapse"
                                                aria-labelledby="heading4"
                                                data-bs-parent="#accordionRow1">
                                                <div class="accordion-body">
                                                    <p class="mb-0">No, it’s
                                                        typically a minimally
                                                        invasive outpatient
                                                        procedure with small
                                                        incisions and a shorter
                                                        recovery time.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="accordion-item">
                                            <h2 class="accordion-header"
                                                id="heading5">
                                                <button
                                                    class="accordion-button collapsed"
                                                    type="button"
                                                    data-bs-toggle="collapse"
                                                    data-bs-target="#collapse5"
                                                    aria-expanded="false"
                                                    aria-controls="collapse5">What
                                                    is the recovery time after
                                                    Bankart Repair?</button>
                                            </h2>
                                            <div id="collapse5"
                                                class="accordion-collapse collapse"
                                                aria-labelledby="heading5"
                                                data-bs-parent="#accordionRow1">
                                                <div class="accordion-body">
                                                    <p class="mb-0">Full
                                                        recovery takes around
                                                        4–6 months, with a sling
                                                        used for the first few
                                                        weeks and gradual
                                                        physical therapy
                                                        afterward.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="accordion-item">
                                            <h2 class="accordion-header"
                                                id="heading6">
                                                <button
                                                    class="accordion-button collapsed"
                                                    type="button"
                                                    data-bs-toggle="collapse"
                                                    data-bs-target="#collapse6"
                                                    aria-expanded="false"
                                                    aria-controls="collapse6">Will
                                                    I regain full shoulder
                                                    function?</button>
                                            </h2>
                                            <div id="collapse6"
                                                class="accordion-collapse collapse"
                                                aria-labelledby="heading6"
                                                data-bs-parent="#accordionRow1">
                                                <div class="accordion-body">
                                                    <p class="mb-0"> Most
                                                        patients regain full
                                                        strength and stability,
                                                        especially with proper
                                                        rehabilitation and
                                                        post-op care.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="accordion-item">
                                            <h2 class="accordion-header"
                                                id="heading7">
                                                <button
                                                    class="accordion-button collapsed"
                                                    type="button"
                                                    data-bs-toggle="collapse"
                                                    data-bs-target="#collapse7"
                                                    aria-expanded="false"
                                                    aria-controls="collapse7">Can
                                                    Bankart Repair prevent
                                                    future
                                                    dislocations?</button>
                                            </h2>
                                            <div id="collapse7"
                                                class="accordion-collapse collapse"
                                                aria-labelledby="heading7"
                                                data-bs-parent="#accordionRow1">
                                                <div class="accordion-body">
                                                    <p class="mb-0">Yes, it
                                                        significantly reduces
                                                        the risk of repeat
                                                        dislocations and
                                                        improves shoulder
                                                        stability.

                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="accordion-item">
                                            <h2 class="accordion-header"
                                                id="heading8">
                                                <button
                                                    class="accordion-button collapsed"
                                                    type="button"
                                                    data-bs-toggle="collapse"
                                                    data-bs-target="#collapse8"
                                                    aria-expanded="false"
                                                    aria-controls="collapse8">Are
                                                    there risks or
                                                    complications?</button>
                                            </h2>
                                            <div id="collapse8"
                                                class="accordion-collapse collapse"
                                                aria-labelledby="heading8"
                                                data-bs-parent="#accordionRow1">
                                                <div class="accordion-body">
                                                    <p class="mb-0">As with any
                                                        surgery, risks include
                                                        infection, stiffness,
                                                        nerve injury, or failure
                                                        of the repair, but these
                                                        are rare with proper
                                                        care.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="accordion-item">
                                            <h2 class="accordion-header"
                                                id="heading9">
                                                <button
                                                    class="accordion-button collapsed"
                                                    type="button"
                                                    data-bs-toggle="collapse"
                                                    data-bs-target="#collapse9"
                                                    aria-expanded="false"
                                                    aria-controls="collapse9">
                                                    Can I return to sports after
                                                    surgery?</button>
                                            </h2>
                                            <div id="collapse9"
                                                class="accordion-collapse collapse"
                                                aria-labelledby="heading9"
                                                data-bs-parent="#accordionRow1">
                                                <div class="accordion-body">
                                                    <p class="mb-0"> Yes, most
                                                        athletes return to
                                                        sports after 4–6 months,
                                                        depending on healing and
                                                        shoulder strength.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="accordion-item">
                                            <h2 class="accordion-header"
                                                id="heading10">
                                                <button
                                                    class="accordion-button collapsed"
                                                    type="button"
                                                    data-bs-toggle="collapse"
                                                    data-bs-target="#collapse10"
                                                    aria-expanded="false"
                                                    aria-controls="collapse10">
                                                    What happens if I don’t get
                                                    the repair done?</button>
                                            </h2>
                                            <div id="collapse10"
                                                class="accordion-collapse collapse"
                                                aria-labelledby="heading10"
                                                data-bs-parent="#accordionRow1">
                                                <div class="accordion-body">
                                                    <p class="mb-0">Without
                                                        treatment, shoulder
                                                        instability may worsen,
                                                        leading to chronic pain,
                                                        more dislocations, and
                                                        damage to the joint over
                                                        time.</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <aside class="sticky-top pb-1">
                                    <div class="widget">
                                        <ul class="service-menu">
                                            <li class="active"><a
                                                    href="acl-reconstruction.html"><span>ACL
                                                        Reconstruction</span> <i
                                                        class="fa fa-angle-right"></i>
                                                </a></li>
                                            <li><a
                                                    href="pcl-reconstruction.html"><span>PCL
                                                        Reconstruction</span> <i
                                                        class="fa fa-angle-right"></i></a></li>
                                            <li><a
                                                    href="cartilage-surgery.html"><span>Cartilage
                                                        Surgery</span> <i
                                                        class="fa fa-angle-right"></i></a></li>
                                            <li><a
                                                    href="bankart-repair.html"><span>Bankart
                                                        Repair</span> <i
                                                        class="fa fa-angle-right"></i></a></li>
                                            <li><a
                                                    href="knee-replacement.html"><span>Knee
                                                        Replacement</span> <i
                                                        class="fa fa-angle-right"></i></a></li>
                                            <li><a
                                                    href="hip-replacement.html"><span>Hip
                                                        Replacement</span> <i
                                                        class="fa fa-angle-right"></i></a></li>
                                            <li><a
                                                    href="arthroscopy-surgery.html"><span>Arthroscopy
                                                        Surgery</span> <i
                                                        class="fa fa-angle-right"></i></a></li>
                                            <li><a
                                                    href="trauma-surgery.html"><span>Trauma
                                                        Surgery</span> <i
                                                        class="fa fa-angle-right"></i></a></li>
                                            <li><a
                                                    href="shoulder-rotator-cuff-repair.html"><span>Shoulder
                                                        rotator cuff
                                                        repair</span> <i
                                                        class="fa fa-angle-right"></i></a></li>
                                        </ul>
                                    </div>

                                </aside>
                            </div>
                        </div>
                    </div>
                </section>
            </div>s

@endsection