@extends('layouts.front')
@section('content')

  
<section class="section pt-5">

<div class="container pt-5">
    <div class="row pt-5">
        <div class="col-lg-6">
            <h3>Thank You for showing interest in our services.</h3>
            <p>We will get back to you soon..</p>
        </div>
        <div class="col-lg-6">
            <img src="assets/img/thank-you.png" />
        </div>
    </div>
</div>

</section>












@endsection