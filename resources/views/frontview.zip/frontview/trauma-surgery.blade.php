

@extends('layouts.front')
@section('opTag')


@section('title', 'Trauma-surgery')

@endsection
@section('content')


 <div class="page-content bg-white">

                <!-- Inner Banner -->
                <div class="banner-wraper">
                    <div class="page-banner"
                        style="background-image:url(/Front/assets/images/banner/img1.jpg);">
                        <div class="container">
                            <div class="page-banner-entry text-center">
                                <h1>Trauma Surgery</h1>
                                <!-- Breadcrumb row -->
                                <nav aria-label="breadcrumb"
                                    class="breadcrumb-row">
                                    <ul class="breadcrumb">
                                        <li class="breadcrumb-item"><a
                                                href="index-2.html"><svg
                                                    xmlns="http://www.w3.org/2000/svg"
                                                    width="22" height="22"
                                                    viewBox="0 0 24 24"
                                                    fill="none"
                                                    stroke="currentColor"
                                                    stroke-width="2"
                                                    stroke-linecap="round"
                                                    stroke-linejoin="round"
                                                    class="feather feather-home"><path
                                                        d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline
                                                        points="9 22 9 12 15 12 15 22"></polyline></svg>
                                                Home</a></li>
                                        <li class="breadcrumb-item active"
                                            aria-current="page">Trauma
                                            Surgery</li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                        <img class="pt-img1 animate-wave"
                            src="{{ asset('Front/assets/images/shap/wave-blue.png') }}" alt>
                        <img class="pt-img2 animate2"
                            src="{{ asset('Front/assets/images/shap/circle-dots.png') }}" alt>
                        <img class="pt-img3 animate-rotate"
                            src="{{ asset('Front/assets/images/shap/plus-blue.png') }}" alt>
                    </div>
                    <!-- Breadcrumb row END -->
                </div>
                <!-- Inner Banner end -->

                <!-- About us -->
                <section class="section-area section-sp1">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-8 mb-30">
                                <div class="ttr-media mb-30">
                                    <img
                                        src="{{ asset('Front/assets/images/service/acl_1280.jpg') }}"
                                        class="rounded" alt>
                                </div>
                                <div class="clearfix">
                                    <div class="head-text mb-30">
                                        <h2 class="title mb-15">Trauma
                                            Surgery</h2>
                                        <p class="mb-0">Trauma surgery is a very
                                            specialized field of medicine that
                                            deals with the diagnosis, proper
                                            treatment, and management of
                                            injuries resulting from accidents,
                                            falls, or violent incidents. The aim
                                            of the best trauma surgery in
                                            Ahmedabad is to provide rapid and
                                            effective medical care to patients
                                            who have suffered serious injuries,
                                            in order to minimize complications
                                            and improve their chances of
                                            survival</p>

                                        <p class="mt-2 mb-0">A trauma surgeon
                                            can perform the procedure on their
                                            own or in a surgical team,
                                            contingent on the severity of the
                                            injury. A general surgeon can also
                                            join the team at times.One surgery
                                            session could require the surgeon to
                                            deal with multiple aspects of your
                                            body, contingent on the injury. A
                                            trauma surgeon usually prioritizes
                                            what they do to treat your injuries
                                            when they occur, since they may
                                            involve bones, internal organs, as
                                            well as soft tissues.</p>

                                        <p class="mt-2 mb-0">After recovery and
                                            rehab following surgeries, trauma
                                            surgeon typically assist patients
                                            while they recover from the surgery.
                                            They can diagnose ailments, conduct
                                            tests, and prescribe medicines for
                                            post-surgical and pre-surgical.</p>
                                    </div>

                                </div>
                                <!-- symptoms start -->
                                <div class>
                                    <h4 class="title">Symptoms of Trauma
                                        Surgery</h4>
                                    <!-- <p>Arthroscopy may be recommended when a joint condition is suspected but not clearly diagnosed using non-invasive imaging techniques (e.g., X-rays, MRIs), or when joint pain persists despite conservative treatments. Common symptoms include:</p> -->
                                    <div class="row align-items-center">
                                        <div class="col-md-12 mb-30">
                                            <ul class="list-check-squer mb-0">
                                                <li>Severe pain at the injury
                                                    site: Sudden, intense pain
                                                    that does not improve with
                                                    rest or over-the-counter
                                                    medications.</li>
                                                <li>Visible bone deformity:
                                                    Limbs appear bent, twisted,
                                                    or out of alignment
                                                    (suggesting fracture or
                                                    dislocation). </li>
                                                <li>Inability to move a limb or
                                                    joint: Loss of function in
                                                    the affected area, such as
                                                    not being able to walk, lift
                                                    an arm, or bend a knee.</li>
                                                <li>Swelling and bruising: Rapid
                                                    swelling, discoloration, or
                                                    visible bruising near the
                                                    injury.</li>
                                                <li>Open wounds with exposed
                                                    bone: Compound (open)
                                                    fractures where the bone
                                                    protrudes through the skin.
                                                </li>
                                                <li>Numbness or tingling: May
                                                    indicate nerve damage or
                                                    compromised blood flow.
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <!-- symptoms end-->
                                <div class="clearfix">
                                    <div class="head-text mb-30">
                                        <h4 class="title mb-10">Popular
                                            Questions</h4>
                                    </div>
                                    <div class="accordion ttr-accordion1"
                                        id="accordionRow1">
                                        <div class="accordion-item">
                                            <h2 class="accordion-header"
                                                id="heading1">
                                                <button class="accordion-button"
                                                    type="button"
                                                    data-bs-toggle="collapse"
                                                    data-bs-target="#collapse1"
                                                    aria-expanded="true"
                                                    aria-controls="collapse1">What
                                                    is Trauma Surgery?</button>
                                            </h2>
                                            <div id="collapse1"
                                                class="accordion-collapse collapse show"
                                                aria-labelledby="heading1"
                                                data-bs-parent="#accordionRow1">
                                                <div class="accordion-body">
                                                    <p class="mb-0">Trauma
                                                        surgery involves
                                                        emergency procedures to
                                                        treat severe injuries
                                                        from accidents, falls,
                                                        or violence, often
                                                        affecting bones, joints,
                                                        and soft tissues.</p>

                                                </div>
                                            </div>
                                        </div>
                                        <div class="accordion-item">
                                            <h2 class="accordion-header"
                                                id="heading2">
                                                <button
                                                    class="accordion-button collapsed"
                                                    type="button"
                                                    data-bs-toggle="collapse"
                                                    data-bs-target="#collapse2"
                                                    aria-expanded="false"
                                                    aria-controls="collapse2">What
                                                    types of injuries require
                                                    trauma surgery?</button>
                                            </h2>
                                            <div id="collapse2"
                                                class="accordion-collapse collapse"
                                                aria-labelledby="heading2"
                                                data-bs-parent="#accordionRow1">
                                                <div class="accordion-body">
                                                    <p class="mb-0">Fractures,
                                                        dislocations, soft
                                                        tissue injuries,
                                                        internal bleeding, and
                                                        complex wounds often
                                                        require trauma surgery.
                                                    </p>

                                                </div>
                                            </div>
                                        </div>
                                        <div class="accordion-item">
                                            <h2 class="accordion-header"
                                                id="heading3">
                                                <button
                                                    class="accordion-button collapsed"
                                                    type="button"
                                                    data-bs-toggle="collapse"
                                                    data-bs-target="#collapse3"
                                                    aria-expanded="false"
                                                    aria-controls="collapse3">Is
                                                    trauma surgery only for
                                                    life-threatening
                                                    injuries?</button>
                                            </h2>
                                            <div id="collapse3"
                                                class="accordion-collapse collapse"
                                                aria-labelledby="heading3"
                                                data-bs-parent="#accordionRow1">
                                                <div class="accordion-body">
                                                    <p class="mb-0">No, it also
                                                        addresses
                                                        non-life-threatening but
                                                        serious injuries that
                                                        need timely surgical
                                                        care to prevent
                                                        complications.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="accordion-item">
                                            <h2 class="accordion-header"
                                                id="heading4">
                                                <button
                                                    class="accordion-button collapsed"
                                                    type="button"
                                                    data-bs-toggle="collapse"
                                                    data-bs-target="#collapse4"
                                                    aria-expanded="false"
                                                    aria-controls="collapse4">What’s
                                                    the difference between
                                                    trauma surgery and regular
                                                    orthopedic surgery?</button>
                                            </h2>
                                            <div id="collapse4"
                                                class="accordion-collapse collapse"
                                                aria-labelledby="heading4"
                                                data-bs-parent="#accordionRow1">
                                                <div class="accordion-body">
                                                    <p class="mb-0">Trauma
                                                        surgery is urgent and
                                                        deals with unexpected
                                                        injuries, while elective
                                                        orthopedic surgery is
                                                        planned for chronic or
                                                        degenerative issues.</p>

                                                </div>
                                            </div>
                                        </div>
                                        <div class="accordion-item">
                                            <h2 class="accordion-header"
                                                id="heading5">
                                                <button
                                                    class="accordion-button collapsed"
                                                    type="button"
                                                    data-bs-toggle="collapse"
                                                    data-bs-target="#collapse5"
                                                    aria-expanded="false"
                                                    aria-controls="collapse5">What
                                                    happens during trauma
                                                    surgery?</button>
                                            </h2>
                                            <div id="collapse5"
                                                class="accordion-collapse collapse"
                                                aria-labelledby="heading5"
                                                data-bs-parent="#accordionRow1">
                                                <div class="accordion-body">
                                                    <p class="mb-0">Surgeons
                                                        stabilize broken bones,
                                                        repair damaged tissues,
                                                        control bleeding, and
                                                        sometimes implant
                                                        hardware like plates or
                                                        screws.</p>

                                                </div>
                                            </div>
                                        </div>
                                        <div class="accordion-item">
                                            <h2 class="accordion-header"
                                                id="heading6">
                                                <button
                                                    class="accordion-button collapsed"
                                                    type="button"
                                                    data-bs-toggle="collapse"
                                                    data-bs-target="#collapse6"
                                                    aria-expanded="false"
                                                    aria-controls="collapse6">How
                                                    soon is trauma surgery
                                                    performed after
                                                    injury?</button>
                                            </h2>
                                            <div id="collapse6"
                                                class="accordion-collapse collapse"
                                                aria-labelledby="heading6"
                                                data-bs-parent="#accordionRow1">
                                                <div class="accordion-body">
                                                    <p class="mb-0">It’s
                                                        typically performed as
                                                        soon as the patient is
                                                        stabilized and imaging
                                                        confirms the extent of
                                                        injury—often within
                                                        hours.</p>

                                                </div>
                                            </div>
                                        </div>
                                        <div class="accordion-item">
                                            <h2 class="accordion-header"
                                                id="heading7">
                                                <button
                                                    class="accordion-button collapsed"
                                                    type="button"
                                                    data-bs-toggle="collapse"
                                                    data-bs-target="#collapse7"
                                                    aria-expanded="false"
                                                    aria-controls="collapse7">What
                                                    is recovery like after
                                                    trauma surgery?</button>
                                            </h2>
                                            <div id="collapse7"
                                                class="accordion-collapse collapse"
                                                aria-labelledby="heading7"
                                                data-bs-parent="#accordionRow1">
                                                <div class="accordion-body">
                                                    <p class="mb-0">Recovery
                                                        depends on injury
                                                        severity but usually
                                                        involves
                                                        hospitalization, pain
                                                        management, wound care,
                                                        and physical
                                                        therapy.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="accordion-item">
                                            <h2 class="accordion-header"
                                                id="heading8">
                                                <button
                                                    class="accordion-button collapsed"
                                                    type="button"
                                                    data-bs-toggle="collapse"
                                                    data-bs-target="#collapse8"
                                                    aria-expanded="false"
                                                    aria-controls="collapse8">Are
                                                    trauma surgeries always
                                                    successful?</button>
                                            </h2>
                                            <div id="collapse8"
                                                class="accordion-collapse collapse"
                                                aria-labelledby="heading8"
                                                data-bs-parent="#accordionRow1">
                                                <div class="accordion-body">
                                                    <p class="mb-0">Outcomes are
                                                        generally good with
                                                        prompt treatment and
                                                        rehabilitation, but
                                                        complications can occur
                                                        depending on the
                                                        injury.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="accordion-item">
                                            <h2 class="accordion-header"
                                                id="heading9">
                                                <button
                                                    class="accordion-button collapsed"
                                                    type="button"
                                                    data-bs-toggle="collapse"
                                                    data-bs-target="#collapse9"
                                                    aria-expanded="false"
                                                    aria-controls="collapse9">Will
                                                    I need follow-up
                                                    surgeries?</button>
                                            </h2>
                                            <div id="collapse9"
                                                class="accordion-collapse collapse"
                                                aria-labelledby="heading9"
                                                data-bs-parent="#accordionRow1">
                                                <div class="accordion-body">
                                                    <p class="mb-0">In some
                                                        cases, additional
                                                        surgeries may be needed
                                                        for hardware removal,
                                                        soft tissue
                                                        reconstruction, or
                                                        delayed healing.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="accordion-item">
                                            <h2 class="accordion-header"
                                                id="heading10">
                                                <button
                                                    class="accordion-button collapsed"
                                                    type="button"
                                                    data-bs-toggle="collapse"
                                                    data-bs-target="#collapse10"
                                                    aria-expanded="false"
                                                    aria-controls="collapse10">Can
                                                    trauma surgery restore full
                                                    function?</button>
                                            </h2>
                                            <div id="collapse10"
                                                class="accordion-collapse collapse"
                                                aria-labelledby="heading10"
                                                data-bs-parent="#accordionRow1">
                                                <div class="accordion-body">
                                                    <p class="mb-0">Many
                                                        patients regain full or
                                                        near-full function,
                                                        especially with proper
                                                        rehab, though results
                                                        vary based on injury
                                                        complexity.</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <aside class="sticky-top pb-1">
                                    <div class="widget">
                                        <ul class="service-menu">
                                            <li class="active"><a
                                                    href="acl-reconstruction.html"><span>ACL
                                                        Reconstruction</span> <i
                                                        class="fa fa-angle-right"></i>
                                                </a></li>
                                            <li><a
                                                    href="pcl-reconstruction.html"><span>PCL
                                                        Reconstruction</span> <i
                                                        class="fa fa-angle-right"></i></a></li>
                                            <li><a
                                                    href="cartilage-surgery.html"><span>Cartilage
                                                        Surgery</span> <i
                                                        class="fa fa-angle-right"></i></a></li>
                                            <li><a
                                                    href="bankart-repair.html"><span>Bankart
                                                        Repair</span> <i
                                                        class="fa fa-angle-right"></i></a></li>
                                            <li><a
                                                    href="knee-replacement.html"><span>Knee
                                                        Replacement</span> <i
                                                        class="fa fa-angle-right"></i></a></li>
                                            <li><a
                                                    href="hip-replacement.html"><span>Hip
                                                        Replacement</span> <i
                                                        class="fa fa-angle-right"></i></a></li>
                                            <li><a
                                                    href="arthroscopy-surgery.html"><span>Arthroscopy
                                                        Surgery</span> <i
                                                        class="fa fa-angle-right"></i></a></li>
                                            <li><a
                                                    href="trauma-surgery.html"><span>Trauma
                                                        Surgery</span> <i
                                                        class="fa fa-angle-right"></i></a></li>
                                            <li><a
                                                    href="shoulder-rotator-cuff-repair.html"><span>Shoulder
                                                        rotator cuff
                                                        repair</span> <i
                                                        class="fa fa-angle-right"></i></a></li>
                                        </ul>
                                    </div>

                                </aside>
                            </div>
                        </div>
                    </div>
                </section>
            </div>

@endsection