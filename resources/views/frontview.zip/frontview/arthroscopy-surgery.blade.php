@extends('layouts.front')
@section('opTag')


@section('title', 'Arthroscopy-surgery')

@endsection
@section('content')



 <div class="page-content bg-white">

                <!-- Inner Banner -->
                <div class="banner-wraper">
                    <div class="page-banner"
                        style="background-image:url(/Front/assets/images/banner/img1.jpg);">
                        <div class="container">
                            <div class="page-banner-entry text-center">
                                <h1>Arthroscopy Surgery</h1>
                                <!-- Breadcrumb row -->
                                <nav aria-label="breadcrumb"
                                    class="breadcrumb-row">
                                    <ul class="breadcrumb">
                                        <li class="breadcrumb-item"><a
                                                href="index-2.html"><svg
                                                    xmlns="http://www.w3.org/2000/svg"
                                                    width="22" height="22"
                                                    viewBox="0 0 24 24"
                                                    fill="none"
                                                    stroke="currentColor"
                                                    stroke-width="2"
                                                    stroke-linecap="round"
                                                    stroke-linejoin="round"
                                                    class="feather feather-home"><path
                                                        d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline
                                                        points="9 22 9 12 15 12 15 22"></polyline></svg>
                                                Home</a></li>
                                        <li class="breadcrumb-item active"
                                            aria-current="page">Arthroscopy
                                            Surgery</li>
                                    </ul>
                                </nav>
                            </div>
                        </div>
                        <img class="pt-img1 animate-wave"
                            src="{{ asset('Front/assets/images/shap/wave-blue.png') }}" alt>
                        <img class="pt-img2 animate2"
                            src="{{ asset('Front/assets/images/shap/circle-dots.png') }}" alt>
                        <img class="pt-img3 animate-rotate"
                            src="{{ asset('Front/assets/images/shap/plus-blue.png') }}" alt>
                    </div>
                    <!-- Breadcrumb row END -->
                </div>
                <!-- Inner Banner end -->

                <!-- About us -->
                <section class="section-area section-sp1">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-8 mb-30">
                                <div class="ttr-media mb-30">
                                    <img
                                        src="{{ asset('Front/assets/images/service/acl_1280.jpg') }}"
                                        class="rounded" alt>
                                </div>
                                <div class="clearfix">
                                    <div class="head-text mb-30">
                                        <h2 class="title mb-15">Arthroscopy
                                            Surgery</h2>
                                        <p class="mb-0">Arthroscopy Surgery is a
                                            minimally invasive surgical
                                            procedure that orthopedic surgeons
                                            use to diagnose and treat joint
                                            disorders. The best arthroscopy
                                            surgeon in Ahmedabad is a highly
                                            skilled and trained medical
                                            professional who specializes in
                                            performing arthroscopic procedures
                                            on patients.</p>

                                        <p class="mt-2 mb-0">As an Arthroscopy
                                            Surgeon in Ahmedabad, the first step
                                            in my process is to conduct a
                                            thorough examination of the
                                            patient’s joint using advanced
                                            imaging technologies, such as MRI or
                                            CT scans. Once the problem is
                                            identified, the arthroscopy doctor
                                            in Ahmedabad uses a small camera
                                            known as an arthroscope, which is
                                            inserted into the joint through a
                                            small incision. The camera allows us
                                            to see inside the joint and perform
                                            a range of procedures, including the
                                            repair of damaged cartilage or
                                            ligaments, removal of bone spurs,
                                            and trimming of damaged tissue.</p>

                                        <p class="mt-2 mb-0">Arthroscopy is a
                                            minimally invasive surgical
                                            procedure used to diagnose and treat
                                            joint problems. It involves
                                            inserting a small camera
                                            (arthroscope) into the joint through
                                            tiny incisions, allowing the surgeon
                                            to view the inside of the joint on a
                                            monitor. It is commonly performed on
                                            joints such as the knee, shoulder,
                                            elbow, hip, ankle, and wrist. The
                                            procedure helps diagnose issues like
                                            cartilage damage, ligament tears,
                                            and inflammation, and can also be
                                            used to treat these problems.</p>
                                    </div>

                                </div>
                                <!-- symptoms start -->
                                <div class>
                                    <h4 class="title">Symptoms Indicating the
                                        Need for Arthroscopy</h4>
                                    <p>Arthroscopy may be recommended when a
                                        joint condition is suspected but not
                                        clearly diagnosed using non-invasive
                                        imaging techniques (e.g., X-rays, MRIs),
                                        or when joint pain persists despite
                                        conservative treatments. Common symptoms
                                        include:</p>
                                    <div class="row align-items-center">
                                        <div class="col-md-12 mb-30">
                                            <ul class="list-check-squer mb-0">
                                                <li>Persistent joint pain: Pain
                                                    that does not improve with
                                                    rest, medications, or
                                                    physical therapy.</li>
                                                <li>Swelling: Chronic swelling
                                                    or fluid buildup within the
                                                    joint.</li>
                                                <li>Joint stiffness: Limited
                                                    range of motion, difficulty
                                                    bending or straightening the
                                                    joint.</li>
                                                <li>Joint instability: The
                                                    sensation that the joint is
                                                    unstable or may “give way”
                                                    during movement.</li>
                                                <li>Clicking or catching
                                                    sensation: Feeling of the
                                                    joint catching or locking
                                                    during movement, often due
                                                    to cartilage tears or loose
                                                    bodies.
                                                </li>
                                                <li>Loss of function: Difficulty
                                                    performing routine
                                                    activities due to joint pain
                                                    or mechanical dysfunction.
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <!-- symptoms end-->
                                <div class="clearfix">
                                    <div class="head-text mb-30">
                                        <h4 class="title mb-10">Popular
                                            Questions</h4>
                                    </div>
                                    <div class="accordion ttr-accordion1"
                                        id="accordionRow1">
                                        <div class="accordion-item">
                                            <h2 class="accordion-header"
                                                id="heading1">
                                                <button class="accordion-button"
                                                    type="button"
                                                    data-bs-toggle="collapse"
                                                    data-bs-target="#collapse1"
                                                    aria-expanded="true"
                                                    aria-controls="collapse1">What
                                                    is Arthroscopy
                                                    Surgery?</button>
                                            </h2>
                                            <div id="collapse1"
                                                class="accordion-collapse collapse show"
                                                aria-labelledby="heading1"
                                                data-bs-parent="#accordionRow1">
                                                <div class="accordion-body">
                                                    <p class="mb-0">Arthroscopy
                                                        is a minimally invasive
                                                        procedure used to
                                                        diagnose and treat joint
                                                        problems using a small
                                                        camera and
                                                        instruments.</p>

                                                </div>
                                            </div>
                                        </div>
                                        <div class="accordion-item">
                                            <h2 class="accordion-header"
                                                id="heading2">
                                                <button
                                                    class="accordion-button collapsed"
                                                    type="button"
                                                    data-bs-toggle="collapse"
                                                    data-bs-target="#collapse2"
                                                    aria-expanded="false"
                                                    aria-controls="collapse2">Which
                                                    joints can be treated with
                                                    arthroscopy?</button>
                                            </h2>
                                            <div id="collapse2"
                                                class="accordion-collapse collapse"
                                                aria-labelledby="heading2"
                                                data-bs-parent="#accordionRow1">
                                                <div class="accordion-body">
                                                    <p class="mb-0">Commonly
                                                        treated joints include
                                                        the knee, shoulder,
                                                        elbow, wrist, ankle, and
                                                        hip.
                                                    </p>

                                                </div>
                                            </div>
                                        </div>
                                        <div class="accordion-item">
                                            <h2 class="accordion-header"
                                                id="heading3">
                                                <button
                                                    class="accordion-button collapsed"
                                                    type="button"
                                                    data-bs-toggle="collapse"
                                                    data-bs-target="#collapse3"
                                                    aria-expanded="false"
                                                    aria-controls="collapse3">What
                                                    conditions are treated with
                                                    arthroscopy?</button>
                                            </h2>
                                            <div id="collapse3"
                                                class="accordion-collapse collapse"
                                                aria-labelledby="heading3"
                                                data-bs-parent="#accordionRow1">
                                                <div class="accordion-body">
                                                    <p class="mb-0">It’s used
                                                        for treating ligament
                                                        tears, cartilage damage,
                                                        joint inflammation,
                                                        loose bone or cartilage
                                                        fragments, and
                                                        impingement.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="accordion-item">
                                            <h2 class="accordion-header"
                                                id="heading4">
                                                <button
                                                    class="accordion-button collapsed"
                                                    type="button"
                                                    data-bs-toggle="collapse"
                                                    data-bs-target="#collapse4"
                                                    aria-expanded="false"
                                                    aria-controls="collapse4">How
                                                    is arthroscopy different
                                                    from open surgery?</button>
                                            </h2>
                                            <div id="collapse4"
                                                class="accordion-collapse collapse"
                                                aria-labelledby="heading4"
                                                data-bs-parent="#accordionRow1">
                                                <div class="accordion-body">
                                                    <p class="mb-0">Arthroscopy
                                                        involves smaller
                                                        incisions, less pain,
                                                        faster recovery, and
                                                        lower risk of
                                                        complications compared
                                                        to open surgery.</p>

                                                </div>
                                            </div>
                                        </div>
                                        <div class="accordion-item">
                                            <h2 class="accordion-header"
                                                id="heading5">
                                                <button
                                                    class="accordion-button collapsed"
                                                    type="button"
                                                    data-bs-toggle="collapse"
                                                    data-bs-target="#collapse5"
                                                    aria-expanded="false"
                                                    aria-controls="collapse5">Is
                                                    arthroscopy
                                                    painful?</button>
                                            </h2>
                                            <div id="collapse5"
                                                class="accordion-collapse collapse"
                                                aria-labelledby="heading5"
                                                data-bs-parent="#accordionRow1">
                                                <div class="accordion-body">
                                                    <p class="mb-0">Mild pain or
                                                        discomfort may occur
                                                        post-surgery, but it's
                                                        usually well managed
                                                        with medication and
                                                        rest.</p>

                                                </div>
                                            </div>
                                        </div>
                                        <div class="accordion-item">
                                            <h2 class="accordion-header"
                                                id="heading6">
                                                <button
                                                    class="accordion-button collapsed"
                                                    type="button"
                                                    data-bs-toggle="collapse"
                                                    data-bs-target="#collapse6"
                                                    aria-expanded="false"
                                                    aria-controls="collapse6">How
                                                    long is the recovery after
                                                    arthroscopy?</button>
                                            </h2>
                                            <div id="collapse6"
                                                class="accordion-collapse collapse"
                                                aria-labelledby="heading6"
                                                data-bs-parent="#accordionRow1">
                                                <div class="accordion-body">
                                                    <p class="mb-0">Recovery
                                                        varies based on the
                                                        joint and procedure but
                                                        typically ranges from a
                                                        few weeks to a few
                                                        months.</p>

                                                </div>
                                            </div>
                                        </div>
                                        <div class="accordion-item">
                                            <h2 class="accordion-header"
                                                id="heading7">
                                                <button
                                                    class="accordion-button collapsed"
                                                    type="button"
                                                    data-bs-toggle="collapse"
                                                    data-bs-target="#collapse7"
                                                    aria-expanded="false"
                                                    aria-controls="collapse7">Will
                                                    I need physical
                                                    therapy?</button>
                                            </h2>
                                            <div id="collapse7"
                                                class="accordion-collapse collapse"
                                                aria-labelledby="heading7"
                                                data-bs-parent="#accordionRow1">
                                                <div class="accordion-body">
                                                    <p class="mb-0">Yes,
                                                        physical therapy is
                                                        often essential to
                                                        restore movement,
                                                        strength, and joint
                                                        function after surgery.
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="accordion-item">
                                            <h2 class="accordion-header"
                                                id="heading8">
                                                <button
                                                    class="accordion-button collapsed"
                                                    type="button"
                                                    data-bs-toggle="collapse"
                                                    data-bs-target="#collapse8"
                                                    aria-expanded="false"
                                                    aria-controls="collapse8">Can
                                                    I walk or use the joint
                                                    right after
                                                    surgery?</button>
                                            </h2>
                                            <div id="collapse8"
                                                class="accordion-collapse collapse"
                                                aria-labelledby="heading8"
                                                data-bs-parent="#accordionRow1">
                                                <div class="accordion-body">
                                                    <p class="mb-0">Limited use
                                                        is often allowed after a
                                                        few days, but full
                                                        weight-bearing or
                                                        activity depends on the
                                                        joint and type of
                                                        repair.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="accordion-item">
                                            <h2 class="accordion-header"
                                                id="heading9">
                                                <button
                                                    class="accordion-button collapsed"
                                                    type="button"
                                                    data-bs-toggle="collapse"
                                                    data-bs-target="#collapse9"
                                                    aria-expanded="false"
                                                    aria-controls="collapse9">Are
                                                    there any risks
                                                    involved?</button>
                                            </h2>
                                            <div id="collapse9"
                                                class="accordion-collapse collapse"
                                                aria-labelledby="heading9"
                                                data-bs-parent="#accordionRow1">
                                                <div class="accordion-body">
                                                    <p class="mb-0">Risks are
                                                        minimal but can include
                                                        infection, stiffness,
                                                        bleeding, or blood
                                                        clots, though
                                                        complications are
                                                        rare.</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="accordion-item">
                                            <h2 class="accordion-header"
                                                id="heading10">
                                                <button
                                                    class="accordion-button collapsed"
                                                    type="button"
                                                    data-bs-toggle="collapse"
                                                    data-bs-target="#collapse10"
                                                    aria-expanded="false"
                                                    aria-controls="collapse10">Is
                                                    arthroscopy a permanent
                                                    solution?</button>
                                            </h2>
                                            <div id="collapse10"
                                                class="accordion-collapse collapse"
                                                aria-labelledby="heading10"
                                                data-bs-parent="#accordionRow1">
                                                <div class="accordion-body">
                                                    <p class="mb-0">It can
                                                        provide lasting relief
                                                        and correction,
                                                        especially when combined
                                                        with proper rehab and
                                                        care, though outcomes
                                                        vary by condition.</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <aside class="sticky-top pb-1">
                                    <div class="widget">
                                        <ul class="service-menu">
                                            <li class="active"><a
                                                    href="acl-reconstruction.html"><span>ACL
                                                        Reconstruction</span> <i
                                                        class="fa fa-angle-right"></i>
                                                </a></li>
                                            <li><a
                                                    href="pcl-reconstruction.html"><span>PCL
                                                        Reconstruction</span> <i
                                                        class="fa fa-angle-right"></i></a></li>
                                            <li><a
                                                    href="cartilage-surgery.html"><span>Cartilage
                                                        Surgery</span> <i
                                                        class="fa fa-angle-right"></i></a></li>
                                            <li><a
                                                    href="bankart-repair.html"><span>Bankart
                                                        Repair</span> <i
                                                        class="fa fa-angle-right"></i></a></li>
                                            <li><a
                                                    href="knee-replacement.html"><span>Knee
                                                        Replacement</span> <i
                                                        class="fa fa-angle-right"></i></a></li>
                                            <li><a
                                                    href="hip-replacement.html"><span>Hip
                                                        Replacement</span> <i
                                                        class="fa fa-angle-right"></i></a></li>
                                            <li><a
                                                    href="arthroscopy-surgery.html"><span>Arthroscopy
                                                        Surgery</span> <i
                                                        class="fa fa-angle-right"></i></a></li>
                                            <li><a
                                                    href="trauma-surgery.html"><span>Trauma
                                                        Surgery</span> <i
                                                        class="fa fa-angle-right"></i></a></li>
                                            <li><a
                                                    href="shoulder-rotator-cuff-repair.html"><span>Shoulder
                                                        rotator cuff
                                                        repair</span> <i
                                                        class="fa fa-angle-right"></i></a></li>
                                        </ul>
                                    </div>

                                </aside>
                            </div>
                        </div>
                    </div>
                </section>
            </div>


@endsection